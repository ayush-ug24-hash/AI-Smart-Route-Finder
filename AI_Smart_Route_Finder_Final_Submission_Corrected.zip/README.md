# AI Smart Route Finder

Final submission package with corrected full-window screenshots, report and presentation.

Run: `python main.py`
