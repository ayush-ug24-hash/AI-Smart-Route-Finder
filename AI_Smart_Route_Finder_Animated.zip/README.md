# AI Smart Route Finder — Animated Edition

Open `index.html` in Chrome or Edge.

Features: A*, BFS, DFS, Greedy Best First, Hill Climbing, animated exploration/path, maze generation and live metrics.
